package Servidor;


// =============================================================
// IMPORTACIONES DEL SERVIDOR HTTP
// =============================================================

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;


// =============================================================
// IMPORTACIONES DE ENTRADA / SALIDA
// =============================================================

import java.io.IOException;
import java.io.OutputStream;


// =============================================================
// IMPORTACIONES DE RED
// =============================================================

import java.net.InetSocketAddress;
import java.net.URLDecoder;


// =============================================================
// IMPORTACIÓN PARA UTF-8
// =============================================================

import java.nio.charset.StandardCharsets;


// =============================================================
// IMPORTACIONES PARA MANEJAR LOS DATOS DE LOS FORMULARIOS
// =============================================================

import java.util.HashMap;
import java.util.Map;


// =============================================================
// IMPORTACIONES DE LOS EJERCICIOS
// =============================================================
//
// Cada vez que agreguemos un ejercicio nuevo,
// importaremos aquí su clase principal.
//
// Ejemplo futuro:
//
// import Desordenados.Empleado;
// import Ordenados.Producto;
// =============================================================

import Desordenados.Alumno;
import Desordenados.Cliente;
import Desordenados.Empleado;


// =============================================================
// CLASE PRINCIPAL DEL SERVIDOR
// =============================================================

public class Servidor {



    // =========================================================
    // MÉTODO MAIN
    // =========================================================
    //
    // Aquí se crea el servidor y se registran todas las rutas
    // que utilizarán las páginas HTML mediante fetch().
    //
    // Todo el proyecto utiliza UN SOLO servidor:
    //
    // http://localhost:8080
    //
    // =========================================================

    public static void main(String[] args) {


        try {


            // =================================================
            // CREAR EL SERVIDOR
            // =================================================
            //
            // El servidor utilizará el puerto 8080.
            //
            // Ejemplo:
            //
            // http://localhost:8080
            //
            // =================================================

            HttpServer servidor =
                    HttpServer.create(

                            new InetSocketAddress(
                                    8080
                            ),

                            0
                    );



            // =================================================
            // RUTA PRINCIPAL DEL SERVIDOR
            // =================================================
            //
            // Ruta:
            //
            // GET /
            //
            // Sirve únicamente para comprobar que Java
            // está ejecutándose correctamente.
            //
            // Si abrimos:
            //
            // http://localhost:8080
            //
            // debe aparecer:
            //
            // Servidor Java en ejecucion
            //
            // =================================================

            servidor.createContext(
                    "/",
                    intercambio -> {


                        // Agregar permisos para que el navegador
                        // pueda comunicarse con Java.
                        agregarCORS(
                                intercambio
                        );


                        // Enviamos una respuesta sencilla.
                        enviarRespuesta(

                                intercambio,

                                200,

                                "Servidor Java en ejecucion"
                        );

                    }
            );



            // #################################################
            // #################################################
            //
            //          DESORDENADO 1 - ALUMNOS
            //
            // #################################################
            // #################################################



            // =================================================
            // DESORDENADO 1
            // INICIALIZAR ARREGLO
            // =================================================
            //
            // Ruta:
            //
            // POST /desordenado1/iniciar
            //
            // Recibe:
            //
            // tam
            //
            // Ejemplo:
            //
            // tam=5
            //
            // =================================================

            servidor.createContext(
                    "/desordenado1/iniciar",
                    intercambio -> {


                        agregarCORS(
                                intercambio
                        );


                        // Si el navegador envía OPTIONS,
                        // respondemos y terminamos.
                        if (
                                esOPTIONS(
                                        intercambio
                                )
                        ) {

                            return;
                        }


                        // Solo aceptamos POST.
                        if (
                                !intercambio
                                        .getRequestMethod()
                                        .equalsIgnoreCase(
                                                "POST"
                                        )
                        ) {


                            enviarRespuesta(

                                    intercambio,

                                    405,

                                    "Metodo no permitido"
                            );


                            return;
                        }


                        try {


                            // Leer los datos enviados por HTML.
                            Map<String, String> datos =
                                    leerFormulario(
                                            intercambio
                                    );


                            // Obtener el tamaño.
                            int tam =
                                    Integer.parseInt(
                                            datos.get(
                                                    "tam"
                                            )
                                    );


                            // Inicializar el arreglo de alumnos.
                            String respuesta =
                                    Alumno.InicializarWeb(
                                            tam
                                    );


                            // Enviar respuesta al navegador.
                            enviarRespuesta(

                                    intercambio,

                                    200,

                                    respuesta
                            );


                        } catch (Exception e) {


                            enviarRespuesta(

                                    intercambio,

                                    400,

                                    "Error: "
                                            + e.getMessage()
                            );

                        }

                    }
            );



            // =================================================
            // DESORDENADO 1
            // DAR DE ALTA
            // =================================================
            //
            // Ruta:
            //
            // POST /desordenado1/alta
            //
            // Recibe:
            //
            // nombre
            // semestre
            // promedio
            //
            // =================================================

            servidor.createContext(
                    "/desordenado1/alta",
                    intercambio -> {


                        agregarCORS(
                                intercambio
                        );


                        if (
                                esOPTIONS(
                                        intercambio
                                )
                        ) {

                            return;
                        }


                        if (
                                !intercambio
                                        .getRequestMethod()
                                        .equalsIgnoreCase(
                                                "POST"
                                        )
                        ) {


                            enviarRespuesta(

                                    intercambio,

                                    405,

                                    "Metodo no permitido"
                            );


                            return;
                        }


                        try {


                            // Leer formulario.
                            Map<String, String> datos =
                                    leerFormulario(
                                            intercambio
                                    );


                            // Obtener nombre.
                            String nombre =
                                    datos.get(
                                            "nombre"
                                    );


                            // Obtener semestre.
                            int semestre =
                                    Integer.parseInt(
                                            datos.get(
                                                    "semestre"
                                            )
                                    );


                            // Obtener promedio.
                            float promedio =
                                    Float.parseFloat(
                                            datos.get(
                                                    "promedio"
                                            )
                                    );


                            // Ejecutar lógica en Alumno.java.
                            String respuesta =
                                    Alumno.AltaWeb(

                                            nombre,
                                            semestre,
                                            promedio
                                    );


                            // Responder al HTML.
                            enviarRespuesta(

                                    intercambio,

                                    200,

                                    respuesta
                            );


                        } catch (Exception e) {


                            enviarRespuesta(

                                    intercambio,

                                    400,

                                    "Error: "
                                            + e.getMessage()
                            );

                        }

                    }
            );



            // =================================================
            // DESORDENADO 1
            // DAR DE BAJA
            // =================================================
            //
            // Ruta:
            //
            // POST /desordenado1/baja
            //
            // Recibe:
            //
            // nombre
            //
            // =================================================

            servidor.createContext(
                    "/desordenado1/baja",
                    intercambio -> {


                        agregarCORS(
                                intercambio
                        );


                        if (
                                esOPTIONS(
                                        intercambio
                                )
                        ) {

                            return;
                        }


                        if (
                                !intercambio
                                        .getRequestMethod()
                                        .equalsIgnoreCase(
                                                "POST"
                                        )
                        ) {


                            enviarRespuesta(

                                    intercambio,

                                    405,

                                    "Metodo no permitido"
                            );


                            return;
                        }


                        try {


                            Map<String, String> datos =
                                    leerFormulario(
                                            intercambio
                                    );


                            String nombre =
                                    datos.get(
                                            "nombre"
                                    );


                            String respuesta =
                                    Alumno.BajaWeb(
                                            nombre
                                    );


                            enviarRespuesta(

                                    intercambio,

                                    200,

                                    respuesta
                            );


                        } catch (Exception e) {


                            enviarRespuesta(

                                    intercambio,

                                    400,

                                    "Error: "
                                            + e.getMessage()
                            );

                        }

                    }
            );



            // =================================================
            // DESORDENADO 1
            // MODIFICAR
            // =================================================
            //
            // Ruta:
            //
            // POST /desordenado1/modificar
            //
            // Recibe:
            //
            // nombre
            // semestre
            // promedio
            //
            // =================================================

            servidor.createContext(
                    "/desordenado1/modificar",
                    intercambio -> {


                        agregarCORS(
                                intercambio
                        );


                        if (
                                esOPTIONS(
                                        intercambio
                                )
                        ) {

                            return;
                        }


                        if (
                                !intercambio
                                        .getRequestMethod()
                                        .equalsIgnoreCase(
                                                "POST"
                                        )
                        ) {


                            enviarRespuesta(

                                    intercambio,

                                    405,

                                    "Metodo no permitido"
                            );


                            return;
                        }


                        try {


                            Map<String, String> datos =
                                    leerFormulario(
                                            intercambio
                                    );


                            String nombre =
                                    datos.get(
                                            "nombre"
                                    );


                            int semestre =
                                    Integer.parseInt(
                                            datos.get(
                                                    "semestre"
                                            )
                                    );


                            float promedio =
                                    Float.parseFloat(
                                            datos.get(
                                                    "promedio"
                                            )
                                    );


                            String respuesta =
                                    Alumno.ModificarWeb(

                                            nombre,
                                            semestre,
                                            promedio
                                    );


                            enviarRespuesta(

                                    intercambio,

                                    200,

                                    respuesta
                            );


                        } catch (Exception e) {


                            enviarRespuesta(

                                    intercambio,

                                    400,

                                    "Error: "
                                            + e.getMessage()
                            );

                        }

                    }
            );



            // =================================================
            // DESORDENADO 1
            // LISTAR UN ALUMNO
            // =================================================
            //
            // Ruta:
            //
            // POST /desordenado1/listaruno
            //
            // Recibe:
            //
            // nombre
            //
            // =================================================

            servidor.createContext(
                    "/desordenado1/listaruno",
                    intercambio -> {


                        agregarCORS(
                                intercambio
                        );


                        if (
                                esOPTIONS(
                                        intercambio
                                )
                        ) {

                            return;
                        }


                        if (
                                !intercambio
                                        .getRequestMethod()
                                        .equalsIgnoreCase(
                                                "POST"
                                        )
                        ) {


                            enviarRespuesta(

                                    intercambio,

                                    405,

                                    "Metodo no permitido"
                            );


                            return;
                        }


                        try {


                            Map<String, String> datos =
                                    leerFormulario(
                                            intercambio
                                    );


                            String nombre =
                                    datos.get(
                                            "nombre"
                                    );


                            String respuesta =
                                    Alumno.ListarUnoWeb(
                                            nombre
                                    );


                            enviarRespuesta(

                                    intercambio,

                                    200,

                                    respuesta
                            );


                        } catch (Exception e) {


                            enviarRespuesta(

                                    intercambio,

                                    400,

                                    "Error: "
                                            + e.getMessage()
                            );

                        }

                    }
            );



            // =================================================
            // DESORDENADO 1
            // LISTAR TODOS
            // =================================================
            //
            // Ruta:
            //
            // GET /desordenado1/listartodos
            //
            // No necesita formulario.
            //
            // =================================================

            servidor.createContext(
                    "/desordenado1/listartodos",
                    intercambio -> {


                        agregarCORS(
                                intercambio
                        );


                        if (
                                esOPTIONS(
                                        intercambio
                                )
                        ) {

                            return;
                        }


                        if (
                                !intercambio
                                        .getRequestMethod()
                                        .equalsIgnoreCase(
                                                "GET"
                                        )
                        ) {


                            enviarRespuesta(

                                    intercambio,

                                    405,

                                    "Metodo no permitido"
                            );


                            return;
                        }


                        try {


                            String respuesta =
                                    Alumno.ListarTodosWeb();


                            enviarRespuesta(

                                    intercambio,

                                    200,

                                    respuesta
                            );


                        } catch (Exception e) {


                            enviarRespuesta(

                                    intercambio,

                                    400,

                                    "Error: "
                                            + e.getMessage()
                            );

                        }

                    }
            );



            // #################################################
            // #################################################
            //
            //          DESORDENADO 2 - CLIENTES
            //
            // #################################################
            // #################################################



            // =================================================
            // DESORDENADO 2
            // INICIALIZAR ARREGLO
            // =================================================
            //
            // Ruta:
            //
            // POST /desordenado2/iniciar
            //
            // Recibe:
            //
            // tam
            //
            // =================================================

            servidor.createContext(
                    "/desordenado2/iniciar",
                    intercambio -> {


                        agregarCORS(
                                intercambio
                        );


                        if (
                                esOPTIONS(
                                        intercambio
                                )
                        ) {

                            return;
                        }


                        if (
                                !intercambio
                                        .getRequestMethod()
                                        .equalsIgnoreCase(
                                                "POST"
                                        )
                        ) {


                            enviarRespuesta(

                                    intercambio,

                                    405,

                                    "Metodo no permitido"
                            );


                            return;
                        }


                        try {


                            Map<String, String> datos =
                                    leerFormulario(
                                            intercambio
                                    );


                            int tam =
                                    Integer.parseInt(
                                            datos.get(
                                                    "tam"
                                            )
                                    );


                            String respuesta =
                                    Cliente.InicializarWeb(
                                            tam
                                    );


                            enviarRespuesta(

                                    intercambio,

                                    200,

                                    respuesta
                            );


                        } catch (Exception e) {


                            enviarRespuesta(

                                    intercambio,

                                    400,

                                    "Error: "
                                            + e.getMessage()
                            );

                        }

                    }
            );



            // =================================================
            // DESORDENADO 2
            // DAR DE ALTA CLIENTE
            // =================================================
            //
            // Ruta:
            //
            // POST /desordenado2/alta
            //
            // Recibe:
            //
            // nombre
            // telefono
            // saldo
            // moroso
            //
            // =================================================

            servidor.createContext(
                    "/desordenado2/alta",
                    intercambio -> {


                        agregarCORS(
                                intercambio
                        );


                        if (
                                esOPTIONS(
                                        intercambio
                                )
                        ) {

                            return;
                        }


                        if (
                                !intercambio
                                        .getRequestMethod()
                                        .equalsIgnoreCase(
                                                "POST"
                                        )
                        ) {


                            enviarRespuesta(

                                    intercambio,

                                    405,

                                    "Metodo no permitido"
                            );


                            return;
                        }


                        try {


                            // Leer formulario.
                            Map<String, String> datos =
                                    leerFormulario(
                                            intercambio
                                    );


                            // Nombre.
                            String nombre =
                                    datos.get(
                                            "nombre"
                                    );


                            // Teléfono.
                            String telefono =
                                    datos.get(
                                            "telefono"
                                    );


                            // Saldo.
                            float saldo =
                                    Float.parseFloat(
                                            datos.get(
                                                    "saldo"
                                            )
                                    );


                            // Estado moroso.
                            //
                            // El frontend debe enviar:
                            //
                            // true
                            //
                            // o
                            //
                            // false
                            //
                            boolean moroso =
                                    Boolean.parseBoolean(
                                            datos.get(
                                                    "moroso"
                                            )
                                    );


                            // Registrar cliente.
                            String respuesta =
                                    Cliente.AltaWeb(

                                            nombre,
                                            telefono,
                                            saldo,
                                            moroso
                                    );


                            enviarRespuesta(

                                    intercambio,

                                    200,

                                    respuesta
                            );


                        } catch (Exception e) {


                            enviarRespuesta(

                                    intercambio,

                                    400,

                                    "Error: "
                                            + e.getMessage()
                            );

                        }

                    }
            );



            // =================================================
            // DESORDENADO 2
            // MODIFICAR ESTADO MOROSO
            // =================================================
            //
            // Ruta:
            //
            // POST /desordenado2/modificar
            //
            // Recibe:
            //
            // nombre
            // moroso
            //
            // No modificamos nombre, teléfono ni saldo.
            //
            // =================================================

            servidor.createContext(
                    "/desordenado2/modificar",
                    intercambio -> {


                        agregarCORS(
                                intercambio
                        );


                        if (
                                esOPTIONS(
                                        intercambio
                                )
                        ) {

                            return;
                        }


                        if (
                                !intercambio
                                        .getRequestMethod()
                                        .equalsIgnoreCase(
                                                "POST"
                                        )
                        ) {


                            enviarRespuesta(

                                    intercambio,

                                    405,

                                    "Metodo no permitido"
                            );


                            return;
                        }


                        try {


                            Map<String, String> datos =
                                    leerFormulario(
                                            intercambio
                                    );


                            String nombre =
                                    datos.get(
                                            "nombre"
                                    );


                            boolean moroso =
                                    Boolean.parseBoolean(
                                            datos.get(
                                                    "moroso"
                                            )
                                    );


                            String respuesta =
                                    Cliente.ModificarWeb(

                                            nombre,
                                            moroso
                                    );


                            enviarRespuesta(

                                    intercambio,

                                    200,

                                    respuesta
                            );


                        } catch (Exception e) {


                            enviarRespuesta(

                                    intercambio,

                                    400,

                                    "Error: "
                                            + e.getMessage()
                            );

                        }

                    }
            );



            // =================================================
            // DESORDENADO 2
            // DAR DE BAJA CLIENTE
            // =================================================
            //
            // Ruta:
            //
            // POST /desordenado2/baja
            //
            // Recibe:
            //
            // nombre
            //
            // =================================================

            servidor.createContext(
                    "/desordenado2/baja",
                    intercambio -> {


                        agregarCORS(
                                intercambio
                        );


                        if (
                                esOPTIONS(
                                        intercambio
                                )
                        ) {

                            return;
                        }


                        if (
                                !intercambio
                                        .getRequestMethod()
                                        .equalsIgnoreCase(
                                                "POST"
                                        )
                        ) {


                            enviarRespuesta(

                                    intercambio,

                                    405,

                                    "Metodo no permitido"
                            );


                            return;
                        }


                        try {


                            Map<String, String> datos =
                                    leerFormulario(
                                            intercambio
                                    );


                            String nombre =
                                    datos.get(
                                            "nombre"
                                    );


                            String respuesta =
                                    Cliente.BajaWeb(
                                            nombre
                                    );


                            enviarRespuesta(

                                    intercambio,

                                    200,

                                    respuesta
                            );


                        } catch (Exception e) {


                            enviarRespuesta(

                                    intercambio,

                                    400,

                                    "Error: "
                                            + e.getMessage()
                            );

                        }

                    }
            );



            // =================================================
            // DESORDENADO 2
            // LISTAR UN CLIENTE
            // =================================================
            //
            // Ruta:
            //
            // POST /desordenado2/listaruno
            //
            // Recibe:
            //
            // nombre
            //
            // Retorna:
            //
            // nombre
            // teléfono
            // saldo
            // moroso
            //
            // =================================================

            servidor.createContext(
                    "/desordenado2/listaruno",
                    intercambio -> {


                        agregarCORS(
                                intercambio
                        );


                        if (
                                esOPTIONS(
                                        intercambio
                                )
                        ) {

                            return;
                        }


                        if (
                                !intercambio
                                        .getRequestMethod()
                                        .equalsIgnoreCase(
                                                "POST"
                                        )
                        ) {


                            enviarRespuesta(

                                    intercambio,

                                    405,

                                    "Metodo no permitido"
                            );


                            return;
                        }


                        try {


                            Map<String, String> datos =
                                    leerFormulario(
                                            intercambio
                                    );


                            String nombre =
                                    datos.get(
                                            "nombre"
                                    );


                            String respuesta =
                                    Cliente.ListarUnoWeb(
                                            nombre
                                    );


                            enviarRespuesta(

                                    intercambio,

                                    200,

                                    respuesta
                            );


                        } catch (Exception e) {


                            enviarRespuesta(

                                    intercambio,

                                    400,

                                    "Error: "
                                            + e.getMessage()
                            );

                        }

                    }
            );



            // =================================================
            // DESORDENADO 2
            // LISTAR TODOS LOS CLIENTES
            // =================================================
            //
            // Ruta:
            //
            // GET /desordenado2/listartodos
            //
            // =================================================

            servidor.createContext(
                    "/desordenado2/listartodos",
                    intercambio -> {


                        agregarCORS(
                                intercambio
                        );


                        if (
                                esOPTIONS(
                                        intercambio
                                )
                        ) {

                            return;
                        }


                        if (
                                !intercambio
                                        .getRequestMethod()
                                        .equalsIgnoreCase(
                                                "GET"
                                        )
                        ) {


                            enviarRespuesta(

                                    intercambio,

                                    405,

                                    "Metodo no permitido"
                            );


                            return;
                        }


                        try {


                            String respuesta =
                                    Cliente.ListarTodosWeb();


                            enviarRespuesta(

                                    intercambio,

                                    200,

                                    respuesta
                            );


                        } catch (Exception e) {


                            enviarRespuesta(

                                    intercambio,

                                    400,

                                    "Error: "
                                            + e.getMessage()
                            );

                        }

                    }
            );



            // #################################################
            // #################################################
            //
            //       AQUÍ AGREGAREMOS FUTUROS EJERCICIOS
            //
            // #################################################
            // #################################################
            //
            // EJEMPLO:
            //
            // DESORDENADO 3
            //
            // /desordenado3/iniciar
            // /desordenado3/alta
            // /desordenado3/baja
            // /desordenado3/modificar
            // /desordenado3/listaruno
            // ...
            //
            // IMPORTANTE:
            //
            // LOS NUEVOS createContext() SIEMPRE VAN
            // ANTES DE servidor.start();
            //
            // #################################################



            // =================================================
            // INICIAR EL SERVIDOR
            // =================================================
            //
            // Esta instrucción debe quedar DESPUÉS de registrar
            // todas las rutas.
            //
            // =================================================

            
         // #########################################################
         // #########################################################
         //
//                   DESORDENADO 3 - EMPLEADOS
         //
         // #########################################################
         // #########################################################


         // =========================================================
         // DESORDENADO 3
         // INICIAR ARREGLO DE EMPLEADOS
         // =========================================================
         //
         // Ruta:
         // POST /desordenado3/iniciar
         //
         // Recibe:
         // tam
         //
         // =========================================================

         servidor.createContext(
                 "/desordenado3/iniciar",
                 intercambio -> {

             // Permitir conexión desde el navegador.
             agregarCORS(intercambio);

             // Si el navegador manda OPTIONS,
             // respondemos y terminamos.
             if (esOPTIONS(intercambio)) {
                 return;
             }

             // Esta ruta solamente acepta POST.
             if (!intercambio
                     .getRequestMethod()
                     .equalsIgnoreCase("POST")) {

                 enviarRespuesta(
                         intercambio,
                         405,
                         "Metodo no permitido"
                 );

                 return;
             }

             try {

                 // Leer los datos enviados desde JavaScript.
                 Map<String, String> datos =
                         leerFormulario(intercambio);

                 // Obtener el tamaño del arreglo.
                 int tam =
                         Integer.parseInt(
                                 datos.get("tam")
                         );

                 // Crear el arreglo de empleados.
                 String respuesta =
                         Empleado.IniciarWeb(tam);

                 // Enviar respuesta a la página.
                 enviarRespuesta(
                         intercambio,
                         200,
                         respuesta
                 );

             } catch (Exception e) {

                 // Si ocurre un error en los datos.
                 enviarRespuesta(
                         intercambio,
                         400,
                         "Error: " + e.getMessage()
                 );
             }

         });


         // =========================================================
         // DESORDENADO 3
         // DAR DE ALTA A UN EMPLEADO
         // =========================================================
         //
         // Ruta:
         // POST /desordenado3/alta
         //
         // Recibe:
         //
         // nombre
         // sexo
         // edad
         //
         // =========================================================

         servidor.createContext(
                 "/desordenado3/alta",
                 intercambio -> {

             agregarCORS(intercambio);

             if (esOPTIONS(intercambio)) {
                 return;
             }

             // Solamente POST.
             if (!intercambio
                     .getRequestMethod()
                     .equalsIgnoreCase("POST")) {

                 enviarRespuesta(
                         intercambio,
                         405,
                         "Metodo no permitido"
                 );

                 return;
             }

             try {

                 // Leer formulario.
                 Map<String, String> datos =
                         leerFormulario(intercambio);

                 // Obtener nombre.
                 String nombre =
                         datos.get("nombre");

                 // Obtener sexo como String.
                 String sexoTexto =
                         datos.get("sexo");

                 // Convertir sexo a char.
                 char sexo =
                         sexoTexto
                                 .toUpperCase()
                                 .charAt(0);

                 // Obtener edad.
                 int edad =
                         Integer.parseInt(
                                 datos.get("edad")
                         );

                 // Registrar empleado.
                 String respuesta =
                         Empleado.AltaWeb(
                                 nombre,
                                 sexo,
                                 edad
                         );

                 // Responder al frontend.
                 enviarRespuesta(
                         intercambio,
                         200,
                         respuesta
                 );

             } catch (Exception e) {

                 enviarRespuesta(
                         intercambio,
                         400,
                         "Error: " + e.getMessage()
                 );
             }

         });


         // =========================================================
         // DESORDENADO 3
         // DAR DE BAJA A UN EMPLEADO
         // =========================================================
         //
         // Ruta:
         // POST /desordenado3/baja
         //
         // Recibe:
         // nombre
         //
         // =========================================================

         servidor.createContext(
                 "/desordenado3/baja",
                 intercambio -> {

             agregarCORS(intercambio);

             if (esOPTIONS(intercambio)) {
                 return;
             }

             if (!intercambio
                     .getRequestMethod()
                     .equalsIgnoreCase("POST")) {

                 enviarRespuesta(
                         intercambio,
                         405,
                         "Metodo no permitido"
                 );

                 return;
             }

             try {

                 // Leer datos.
                 Map<String, String> datos =
                         leerFormulario(intercambio);

                 // Obtener nombre del empleado.
                 String nombre =
                         datos.get("nombre");

                 // Dar de baja.
                 String respuesta =
                         Empleado.BajaWeb(nombre);

                 // Enviar respuesta.
                 enviarRespuesta(
                         intercambio,
                         200,
                         respuesta
                 );

             } catch (Exception e) {

                 enviarRespuesta(
                         intercambio,
                         400,
                         "Error: " + e.getMessage()
                 );
             }

         });


         // =========================================================
         // DESORDENADO 3
         // MODIFICAR EDAD DEL EMPLEADO
         // =========================================================
         //
         // Ruta:
         // POST /desordenado3/modificar
         //
         // Recibe:
         //
         // nombre
         // edad
         //
         // IMPORTANTE:
         // Este ejercicio solamente permite modificar la EDAD.
         //
         // =========================================================

         servidor.createContext(
                 "/desordenado3/modificar",
                 intercambio -> {

             agregarCORS(intercambio);

             if (esOPTIONS(intercambio)) {
                 return;
             }

             if (!intercambio
                     .getRequestMethod()
                     .equalsIgnoreCase("POST")) {

                 enviarRespuesta(
                         intercambio,
                         405,
                         "Metodo no permitido"
                 );

                 return;
             }

             try {

                 // Leer formulario.
                 Map<String, String> datos =
                         leerFormulario(intercambio);

                 // Obtener nombre.
                 String nombre =
                         datos.get("nombre");

                 // Obtener nueva edad.
                 int edad =
                         Integer.parseInt(
                                 datos.get("edad")
                         );

                 // Modificar únicamente la edad.
                 String respuesta =
                         Empleado.ModificarWeb(
                                 nombre,
                                 edad
                         );

                 enviarRespuesta(
                         intercambio,
                         200,
                         respuesta
                 );

             } catch (Exception e) {

                 enviarRespuesta(
                         intercambio,
                         400,
                         "Error: " + e.getMessage()
                 );
             }

         });


         // =========================================================
         // DESORDENADO 3
         // LISTAR EMPLEADOS VARONES
         // =========================================================
         //
         // Ruta:
         // GET /desordenado3/listarvarones
         //
         // No necesita recibir datos.
         //
         // Retorna solamente empleados cuyo sexo sea M.
         //
         // =========================================================

         servidor.createContext(
                 "/desordenado3/listarvarones",
                 intercambio -> {

             agregarCORS(intercambio);

             if (esOPTIONS(intercambio)) {
                 return;
             }

             // Esta ruta utiliza GET.
             if (!intercambio
                     .getRequestMethod()
                     .equalsIgnoreCase("GET")) {

                 enviarRespuesta(
                         intercambio,
                         405,
                         "Metodo no permitido"
                 );

                 return;
             }

             try {

                 // Obtener empleados varones.
                 String respuesta =
                         Empleado.ListarVaronesWeb();

                 // Enviar resultado.
                 enviarRespuesta(
                         intercambio,
                         200,
                         respuesta
                 );

             } catch (Exception e) {

                 enviarRespuesta(
                         intercambio,
                         400,
                         "Error: " + e.getMessage()
                 );
             }

         });


         // =========================================================
         // DESORDENADO 3
         // LISTAR UN EMPLEADO DETERMINADO
         // =========================================================
         //
         // Ruta:
         // POST /desordenado3/listaruno
         //
         // Recibe:
         // nombre
         //
         // =========================================================

         servidor.createContext(
                 "/desordenado3/listaruno",
                 intercambio -> {

             agregarCORS(intercambio);

             if (esOPTIONS(intercambio)) {
                 return;
             }

             if (!intercambio
                     .getRequestMethod()
                     .equalsIgnoreCase("POST")) {

                 enviarRespuesta(
                         intercambio,
                         405,
                         "Metodo no permitido"
                 );

                 return;
             }

             try {

                 // Leer datos enviados.
                 Map<String, String> datos =
                         leerFormulario(intercambio);

                 // Nombre del empleado a buscar.
                 String nombre =
                         datos.get("nombre");

                 // Buscar empleado.
                 String respuesta =
                         Empleado.ListarUnoWeb(nombre);

                 // Enviar información al frontend.
                 enviarRespuesta(
                         intercambio,
                         200,
                         respuesta
                 );

             } catch (Exception e) {

                 enviarRespuesta(
                         intercambio,
                         400,
                         "Error: " + e.getMessage()
                 );
             }

         });
         
      // =========================================================
      // DESORDENADO 3
      // LISTAR TODOS LOS EMPLEADOS
      // =========================================================
      //
      // Ruta:
      //
      // GET /desordenado3/listartodos
      //
      // Devuelve TODOS los empleados registrados,
      // tanto masculinos como femeninos.
      //
      // =========================================================

      servidor.createContext(
              "/desordenado3/listartodos",
              intercambio -> {

          // Permitir conexión desde el navegador.
          agregarCORS(intercambio);


          // Atender petición OPTIONS.
          if (esOPTIONS(intercambio)) {

              return;
          }


          // Esta ruta solamente acepta GET.
          if (!intercambio
                  .getRequestMethod()
                  .equalsIgnoreCase("GET")) {

              enviarRespuesta(
                      intercambio,
                      405,
                      "Metodo no permitido"
              );

              return;
          }


          try {

              // Obtener todos los empleados.
              String respuesta =
                      Empleado.ListarTodosWeb();


              // Enviar los registros al frontend.
              enviarRespuesta(
                      intercambio,
                      200,
                      respuesta
              );


          } catch (Exception e) {

              enviarRespuesta(
                      intercambio,
                      400,
                      "Error: " + e.getMessage()
              );
          }

      });
      
   // =========================================================
   // ORDENADO 1 - EMPLEADOS
   // =========================================================


   // =========================================================
   // INICIAR ARREGLO
   // POST /ordenado1/iniciar
   // =========================================================

   servidor.createContext(
           "/ordenado1/iniciar",
           intercambio -> {

       agregarCORS(intercambio);

       if (esOPTIONS(intercambio)) {
           return;
       }

       if (!intercambio
               .getRequestMethod()
               .equalsIgnoreCase("POST")) {

           enviarRespuesta(
                   intercambio,
                   405,
                   "Metodo no permitido"
           );

           return;
       }

       try {

           Map<String, String> datos =
                   leerFormulario(intercambio);

           int tam =
                   Integer.parseInt(
                           datos.get("tam")
                   );

           String respuesta =
                   Ordenados.Empleado.InicializarWeb(
                           tam
                   );

           enviarRespuesta(
                   intercambio,
                   200,
                   respuesta
           );

       } catch (Exception e) {

           enviarRespuesta(
                   intercambio,
                   400,
                   "Error: " + e.getMessage()
           );
       }

   });


   // =========================================================
   // DAR DE ALTA
   // POST /ordenado1/alta
   // =========================================================

   servidor.createContext(
           "/ordenado1/alta",
           intercambio -> {

       agregarCORS(intercambio);

       if (esOPTIONS(intercambio)) {
           return;
       }

       if (!intercambio
               .getRequestMethod()
               .equalsIgnoreCase("POST")) {

           enviarRespuesta(
                   intercambio,
                   405,
                   "Metodo no permitido"
           );

           return;
       }

       try {

           Map<String, String> datos =
                   leerFormulario(intercambio);

           String nombre =
                   datos.get("nombre");

           String direccion =
                   datos.get("direccion");

           int edad =
                   Integer.parseInt(
                           datos.get("edad")
                   );

           char sexo =
                   datos.get("sexo")
                           .toUpperCase()
                           .charAt(0);

           int antiguedad =
                   Integer.parseInt(
                           datos.get("antiguedad")
                   );

           String respuesta =
                   Ordenados.Empleado.AltaWeb(
                           nombre,
                           direccion,
                           edad,
                           sexo,
                           antiguedad
                   );

           enviarRespuesta(
                   intercambio,
                   200,
                   respuesta
           );

       } catch (Exception e) {

           enviarRespuesta(
                   intercambio,
                   400,
                   "Error: " + e.getMessage()
           );
       }

   });


   // =========================================================
   // DAR DE BAJA
   // POST /ordenado1/baja
   // =========================================================

   servidor.createContext(
           "/ordenado1/baja",
           intercambio -> {

       agregarCORS(intercambio);

       if (esOPTIONS(intercambio)) {
           return;
       }

       if (!intercambio
               .getRequestMethod()
               .equalsIgnoreCase("POST")) {

           enviarRespuesta(
                   intercambio,
                   405,
                   "Metodo no permitido"
           );

           return;
       }

       try {

           Map<String, String> datos =
                   leerFormulario(intercambio);

           String nombre =
                   datos.get("nombre");

           String respuesta =
                   Ordenados.Empleado.BajaWeb(
                           nombre
                   );

           enviarRespuesta(
                   intercambio,
                   200,
                   respuesta
           );

       } catch (Exception e) {

           enviarRespuesta(
                   intercambio,
                   400,
                   "Error: " + e.getMessage()
           );
       }

   });


   // =========================================================
   // MODIFICAR ANTIGUEDAD
   // POST /ordenado1/modificar
   // =========================================================

   servidor.createContext(
           "/ordenado1/modificar",
           intercambio -> {

       agregarCORS(intercambio);

       if (esOPTIONS(intercambio)) {
           return;
       }

       if (!intercambio
               .getRequestMethod()
               .equalsIgnoreCase("POST")) {

           enviarRespuesta(
                   intercambio,
                   405,
                   "Metodo no permitido"
           );

           return;
       }

       try {

           Map<String, String> datos =
                   leerFormulario(intercambio);

           String nombre =
                   datos.get("nombre");

           int antiguedad =
                   Integer.parseInt(
                           datos.get("antiguedad")
                   );

           String respuesta =
                   Ordenados.Empleado.ModificarWeb(
                           nombre,
                           antiguedad
                   );

           enviarRespuesta(
                   intercambio,
                   200,
                   respuesta
           );

       } catch (Exception e) {

           enviarRespuesta(
                   intercambio,
                   400,
                   "Error: " + e.getMessage()
           );
       }

   });


   // =========================================================
   // LISTAR UN EMPLEADO
   // POST /ordenado1/listaruno
   // =========================================================

   servidor.createContext(
           "/ordenado1/listaruno",
           intercambio -> {

       agregarCORS(intercambio);

       if (esOPTIONS(intercambio)) {
           return;
       }

       if (!intercambio
               .getRequestMethod()
               .equalsIgnoreCase("POST")) {

           enviarRespuesta(
                   intercambio,
                   405,
                   "Metodo no permitido"
           );

           return;
       }

       try {

           Map<String, String> datos =
                   leerFormulario(intercambio);

           String nombre =
                   datos.get("nombre");

           String respuesta =
                   Ordenados.Empleado.ListarUnoWeb(
                           nombre
                   );

           enviarRespuesta(
                   intercambio,
                   200,
                   respuesta
           );

       } catch (Exception e) {

           enviarRespuesta(
                   intercambio,
                   400,
                   "Error: " + e.getMessage()
           );
       }

   });


   // =========================================================
   // LISTAR TODOS
   // GET /ordenado1/listartodos
   // =========================================================

   servidor.createContext(
           "/ordenado1/listartodos",
           intercambio -> {

       agregarCORS(intercambio);

       if (esOPTIONS(intercambio)) {
           return;
       }

       if (!intercambio
               .getRequestMethod()
               .equalsIgnoreCase("GET")) {

           enviarRespuesta(
                   intercambio,
                   405,
                   "Metodo no permitido"
           );

           return;
       }

       try {

           String respuesta =
                   Ordenados.Empleado.ListarTodosWeb();

           enviarRespuesta(
                   intercambio,
                   200,
                   respuesta
           );

       } catch (Exception e) {

           enviarRespuesta(
                   intercambio,
                   400,
                   "Error: " + e.getMessage()
           );
       }

   });
   
// =========================================================
// ORDENADO 2 - DEPARTAMENTOS
// =========================================================


// =========================================================
// INICIAR ARREGLO
// POST /ordenado2/iniciar
// =========================================================

servidor.createContext(
        "/ordenado2/iniciar",
        intercambio -> {

    agregarCORS(intercambio);

    if (esOPTIONS(intercambio)) {
        return;
    }

    if (!intercambio
            .getRequestMethod()
            .equalsIgnoreCase("POST")) {

        enviarRespuesta(
                intercambio,
                405,
                "Metodo no permitido"
        );

        return;
    }

    try {

        Map<String, String> datos =
                leerFormulario(intercambio);

        int tam =
                Integer.parseInt(
                        datos.get("tam")
                );

        String respuesta =
                Ordenados.Departamento.InicializarWeb(
                        tam
                );

        enviarRespuesta(
                intercambio,
                200,
                respuesta
        );

    } catch (Exception e) {

        enviarRespuesta(
                intercambio,
                400,
                "Error: " + e.getMessage()
        );
    }

});


// =========================================================
// DAR DE ALTA
// POST /ordenado2/alta
// =========================================================
//
// Recibe:
// ubicacion
// extension
// precio
// numeroApartamento
// nombrePersona
//
// =========================================================

servidor.createContext(
        "/ordenado2/alta",
        intercambio -> {

    agregarCORS(intercambio);

    if (esOPTIONS(intercambio)) {
        return;
    }

    if (!intercambio
            .getRequestMethod()
            .equalsIgnoreCase("POST")) {

        enviarRespuesta(
                intercambio,
                405,
                "Metodo no permitido"
        );

        return;
    }

    try {

        Map<String, String> datos =
                leerFormulario(intercambio);

        String ubicacion =
                datos.get("ubicacion");

        float extension =
                Float.parseFloat(
                        datos.get("extension")
                );

        float precio =
                Float.parseFloat(
                        datos.get("precio")
                );

        int numeroApartamento =
                Integer.parseInt(
                        datos.get("numeroApartamento")
                );

        String nombrePersona =
                datos.get("nombrePersona");

        String respuesta =
                Ordenados.Departamento.AltaWeb(
                        ubicacion,
                        extension,
                        precio,
                        numeroApartamento,
                        nombrePersona
                );

        enviarRespuesta(
                intercambio,
                200,
                respuesta
        );

    } catch (Exception e) {

        enviarRespuesta(
                intercambio,
                400,
                "Error: " + e.getMessage()
        );
    }

});


// =========================================================
// DAR DE BAJA
// POST /ordenado2/baja
// =========================================================
//
// Se identifica el departamento por número.
//
// Recibe:
// numeroApartamento
//
// =========================================================

servidor.createContext(
        "/ordenado2/baja",
        intercambio -> {

    agregarCORS(intercambio);

    if (esOPTIONS(intercambio)) {
        return;
    }

    if (!intercambio
            .getRequestMethod()
            .equalsIgnoreCase("POST")) {

        enviarRespuesta(
                intercambio,
                405,
                "Metodo no permitido"
        );

        return;
    }

    try {

        Map<String, String> datos =
                leerFormulario(intercambio);

        int numeroApartamento =
                Integer.parseInt(
                        datos.get("numeroApartamento")
                );

        String respuesta =
                Ordenados.Departamento.BajaWeb(
                        numeroApartamento
                );

        enviarRespuesta(
                intercambio,
                200,
                respuesta
        );

    } catch (Exception e) {

        enviarRespuesta(
                intercambio,
                400,
                "Error: " + e.getMessage()
        );
    }

});


// =========================================================
// MODIFICAR PRECIO
// POST /ordenado2/modificar
// =========================================================
//
// Recibe:
// numeroApartamento
// precio
//
// =========================================================

servidor.createContext(
        "/ordenado2/modificar",
        intercambio -> {

    agregarCORS(intercambio);

    if (esOPTIONS(intercambio)) {
        return;
    }

    if (!intercambio
            .getRequestMethod()
            .equalsIgnoreCase("POST")) {

        enviarRespuesta(
                intercambio,
                405,
                "Metodo no permitido"
        );

        return;
    }

    try {

        Map<String, String> datos =
                leerFormulario(intercambio);

        int numeroApartamento =
                Integer.parseInt(
                        datos.get("numeroApartamento")
                );

        float nuevoPrecio =
                Float.parseFloat(
                        datos.get("precio")
                );

        String respuesta =
                Ordenados.Departamento.ModificarWeb(
                        numeroApartamento,
                        nuevoPrecio
                );

        enviarRespuesta(
                intercambio,
                200,
                respuesta
        );

    } catch (Exception e) {

        enviarRespuesta(
                intercambio,
                400,
                "Error: " + e.getMessage()
        );
    }

});


// =========================================================
// LISTAR UN DEPARTAMENTO
// POST /ordenado2/listaruno
// =========================================================
//
// Recibe:
// numeroApartamento
//
// =========================================================

servidor.createContext(
        "/ordenado2/listaruno",
        intercambio -> {

    agregarCORS(intercambio);

    if (esOPTIONS(intercambio)) {
        return;
    }

    if (!intercambio
            .getRequestMethod()
            .equalsIgnoreCase("POST")) {

        enviarRespuesta(
                intercambio,
                405,
                "Metodo no permitido"
        );

        return;
    }

    try {

        Map<String, String> datos =
                leerFormulario(intercambio);

        int numeroApartamento =
                Integer.parseInt(
                        datos.get("numeroApartamento")
                );

        String respuesta =
                Ordenados.Departamento.ListarUnoWeb(
                        numeroApartamento
                );

        enviarRespuesta(
                intercambio,
                200,
                respuesta
        );

    } catch (Exception e) {

        enviarRespuesta(
                intercambio,
                400,
                "Error: " + e.getMessage()
        );
    }

});


// =========================================================
// LISTAR TODOS
// GET /ordenado2/listartodos
// =========================================================

servidor.createContext(
        "/ordenado2/listartodos",
        intercambio -> {

    agregarCORS(intercambio);

    if (esOPTIONS(intercambio)) {
        return;
    }

    if (!intercambio
            .getRequestMethod()
            .equalsIgnoreCase("GET")) {

        enviarRespuesta(
                intercambio,
                405,
                "Metodo no permitido"
        );

        return;
    }

    try {

        String respuesta =
                Ordenados.Departamento.ListarTodosWeb();

        enviarRespuesta(
                intercambio,
                200,
                respuesta
        );

    } catch (Exception e) {

        enviarRespuesta(
                intercambio,
                400,
                "Error: " + e.getMessage()
        );
    }

});

//=========================================================
//ORDENADO 3 - VENDEDORES
//=========================================================


//=========================================================
//INICIAR ARREGLO
//POST /ordenado3/iniciar
//=========================================================

servidor.createContext(
     "/ordenado3/iniciar",
     intercambio -> {

 agregarCORS(intercambio);

 if (esOPTIONS(intercambio)) {
     return;
 }

 if (!intercambio
         .getRequestMethod()
         .equalsIgnoreCase("POST")) {

     enviarRespuesta(
             intercambio,
             405,
             "Metodo no permitido"
     );

     return;
 }

 try {

     Map<String, String> datos =
             leerFormulario(intercambio);

     int tam =
             Integer.parseInt(
                     datos.get("tam")
             );

     String respuesta =
             Ordenados.Vendedor.InicializarWeb(
                     tam
             );

     enviarRespuesta(
             intercambio,
             200,
             respuesta
     );

 } catch (Exception e) {

     enviarRespuesta(
             intercambio,
             400,
             "Error: " + e.getMessage()
     );
 }

});


//=========================================================
//DAR DE ALTA A UN VENDEDOR
//POST /ordenado3/alta
//=========================================================
//
//Recibe:
//nombre
//totalVentas
//
//=========================================================

servidor.createContext(
     "/ordenado3/alta",
     intercambio -> {

 agregarCORS(intercambio);

 if (esOPTIONS(intercambio)) {
     return;
 }

 if (!intercambio
         .getRequestMethod()
         .equalsIgnoreCase("POST")) {

     enviarRespuesta(
             intercambio,
             405,
             "Metodo no permitido"
     );

     return;
 }

 try {

     Map<String, String> datos =
             leerFormulario(intercambio);

     String nombre =
             datos.get("nombre");

     float totalVentas =
             Float.parseFloat(
                     datos.get("totalVentas")
             );

     String respuesta =
             Ordenados.Vendedor.AltaWeb(
                     nombre,
                     totalVentas
             );

     enviarRespuesta(
             intercambio,
             200,
             respuesta
     );

 } catch (Exception e) {

     enviarRespuesta(
             intercambio,
             400,
             "Error: " + e.getMessage()
     );
 }

});


//=========================================================
//MODIFICAR TOTAL DE VENTAS
//POST /ordenado3/modificar
//=========================================================
//
//Recibe:
//nombre
//totalVentas
//
//=========================================================

servidor.createContext(
     "/ordenado3/modificar",
     intercambio -> {

 agregarCORS(intercambio);

 if (esOPTIONS(intercambio)) {
     return;
 }

 if (!intercambio
         .getRequestMethod()
         .equalsIgnoreCase("POST")) {

     enviarRespuesta(
             intercambio,
             405,
             "Metodo no permitido"
     );

     return;
 }

 try {

     Map<String, String> datos =
             leerFormulario(intercambio);

     String nombre =
             datos.get("nombre");

     float totalVentas =
             Float.parseFloat(
                     datos.get("totalVentas")
             );

     String respuesta =
             Ordenados.Vendedor.ModificarWeb(
                     nombre,
                     totalVentas
             );

     enviarRespuesta(
             intercambio,
             200,
             respuesta
     );

 } catch (Exception e) {

     enviarRespuesta(
             intercambio,
             400,
             "Error: " + e.getMessage()
     );
 }

});


//=========================================================
//LISTAR UN VENDEDOR
//POST /ordenado3/listaruno
//=========================================================
//
//Recibe:
//nombre
//
//=========================================================

servidor.createContext(
     "/ordenado3/listaruno",
     intercambio -> {

 agregarCORS(intercambio);

 if (esOPTIONS(intercambio)) {
     return;
 }

 if (!intercambio
         .getRequestMethod()
         .equalsIgnoreCase("POST")) {

     enviarRespuesta(
             intercambio,
             405,
             "Metodo no permitido"
     );

     return;
 }

 try {

     Map<String, String> datos =
             leerFormulario(intercambio);

     String nombre =
             datos.get("nombre");

     String respuesta =
             Ordenados.Vendedor.ListarUnoWeb(
                     nombre
             );

     enviarRespuesta(
             intercambio,
             200,
             respuesta
     );

 } catch (Exception e) {

     enviarRespuesta(
             intercambio,
             400,
             "Error: " + e.getMessage()
     );
 }

});
            
            servidor.start();



            // Mensaje en la consola de Eclipse.

            System.out.println(
                    "Servidor iniciado en el puerto 8080"
            );



        } catch (Exception e) {


            // Si por ejemplo el puerto 8080 está ocupado,
            // entraremos aquí.

            System.out.println(

                    "Error al iniciar el servidor: "
                            + e.getMessage()
            );


            // Mostrar información completa del error.
            e.printStackTrace();

        }


    } // fin main





    // #########################################################
    // #########################################################
    //
    //             MÉTODOS GENERALES DEL SERVIDOR
    //
    // #########################################################
    // #########################################################
    //
    // ESTOS MÉTODOS SON REUTILIZADOS POR TODOS LOS EJERCICIOS.
    //
    // NO ES NECESARIO COPIARLOS PARA CADA EJERCICIO.
    //
    // #########################################################





    // =========================================================
    // LEER DATOS DE UN FORMULARIO
    // =========================================================
    //
    // Este método convierte lo que envía JavaScript:
    //
    // nombre=Denis&semestre=4&promedio=90
    //
    // en un Map:
    //
    // datos.get("nombre")    -> Denis
    // datos.get("semestre")  -> 4
    // datos.get("promedio")  -> 90
    //
    // Así evitamos repetir esta lógica en todas las rutas.
    //
    // =========================================================

    public static Map<String, String> leerFormulario(
            HttpExchange intercambio)
            throws IOException {


        // -----------------------------------------------------
        // LEER CUERPO DE LA PETICIÓN
        // -----------------------------------------------------

        byte[] cuerpo =
                intercambio
                        .getRequestBody()
                        .readAllBytes();



        // -----------------------------------------------------
        // CONVERTIR BYTES A TEXTO
        // -----------------------------------------------------

        String formulario =
                new String(

                        cuerpo,

                        StandardCharsets.UTF_8
                );



        // -----------------------------------------------------
        // CREAR MAPA
        // -----------------------------------------------------

        Map<String, String> datos =
                new HashMap<>();



        // Si no se enviaron datos,
        // devolvemos el mapa vacío.

        if (
                formulario.isEmpty()
        ) {


            return datos;

        }



        // -----------------------------------------------------
        // SEPARAR LOS PARÁMETROS
        // -----------------------------------------------------
        //
        // Ejemplo:
        //
        // nombre=Denis&saldo=500
        //
        // se convierte en:
        //
        // nombre=Denis
        // saldo=500
        //
        // -----------------------------------------------------

        String[] parametros =
                formulario.split(
                        "&"
                );



        // -----------------------------------------------------
        // RECORRER CADA PARÁMETRO
        // -----------------------------------------------------

        for (
                String parametro :
                parametros
        ) {


            // Separar clave y valor.
            //
            // nombre=Denis
            //
            // partes[0] = nombre
            // partes[1] = Denis

            String[] partes =
                    parametro.split(
                            "=",
                            2
                    );



            if (
                    partes.length == 2
            ) {


                // ---------------------------------------------
                // DECODIFICAR CLAVE
                // ---------------------------------------------

                String clave =
                        URLDecoder.decode(

                                partes[0],

                                StandardCharsets.UTF_8
                        );



                // ---------------------------------------------
                // DECODIFICAR VALOR
                // ---------------------------------------------
                //
                // Esto permite correctamente espacios,
                // tildes y caracteres especiales.
                //
                // Ejemplo:
                //
                // Denis%20Vallecillo
                //
                // se convierte en:
                //
                // Denis Vallecillo
                //
                // ---------------------------------------------

                String valor =
                        URLDecoder.decode(

                                partes[1],

                                StandardCharsets.UTF_8
                        );



                // Guardar en el mapa.

                datos.put(
                        clave,
                        valor
                );

            }

        }



        // Devolver información procesada.

        return datos;

    } // fin leerFormulario





    // =========================================================
    // ENVIAR RESPUESTA AL FRONTEND
    // =========================================================
    //
    // Todos los ejercicios utilizan este método para responder.
    //
    // Ejemplo:
    //
    // enviarRespuesta(
    //      intercambio,
    //      200,
    //      "Alumno registrado correctamente"
    // );
    //
    // =========================================================

    public static void enviarRespuesta(

            HttpExchange intercambio,

            int codigo,

            String respuesta
    )
            throws IOException {


        // -----------------------------------------------------
        // CONVERTIR RESPUESTA A BYTES UTF-8
        // -----------------------------------------------------

        byte[] bytes =
                respuesta.getBytes(
                        StandardCharsets.UTF_8
                );



        // -----------------------------------------------------
        // INDICAR TIPO DE CONTENIDO
        // -----------------------------------------------------

        intercambio
                .getResponseHeaders()
                .set(

                        "Content-Type",

                        "text/plain; charset=UTF-8"
                );



        // -----------------------------------------------------
        // ENVIAR CÓDIGO HTTP
        // -----------------------------------------------------
        //
        // 200 = Correcto
        // 400 = Error de datos
        // 405 = Método HTTP no permitido
        //
        // -----------------------------------------------------

        intercambio.sendResponseHeaders(

                codigo,

                bytes.length
        );



        // -----------------------------------------------------
        // ESCRIBIR RESPUESTA
        // -----------------------------------------------------

        try (

                OutputStream salida =
                        intercambio
                                .getResponseBody()

        ) {


            salida.write(
                    bytes
            );

        }


    } // fin enviarRespuesta





    // =========================================================
    // CONFIGURAR CORS
    // =========================================================
    //
    // CORS permite que nuestro HTML pueda comunicarse
    // con Java aunque estén ejecutándose desde lugares
    // diferentes.
    //
    // Por ejemplo:
    //
    // HTML:
    // http://127.0.0.1:5500
    //
    // JAVA:
    // http://localhost:8080
    //
    // Sin estos encabezados, el navegador podría bloquear
    // la petición.
    //
    // =========================================================

    public static void agregarCORS(
            HttpExchange intercambio) {


        // Permitir cualquier origen.

        intercambio
                .getResponseHeaders()
                .set(

                        "Access-Control-Allow-Origin",

                        "*"
                );



        // Métodos HTTP permitidos.

        intercambio
                .getResponseHeaders()
                .set(

                        "Access-Control-Allow-Methods",

                        "GET, POST, OPTIONS"
                );



        // Encabezados permitidos.

        intercambio
                .getResponseHeaders()
                .set(

                        "Access-Control-Allow-Headers",

                        "Content-Type"
                );


    } // fin agregarCORS





    // =========================================================
    // RESPONDER PETICIONES OPTIONS
    // =========================================================
    //
    // El navegador puede enviar una petición OPTIONS antes
    // de realizar un POST.
    //
    // Esta función detecta esa petición y responde correctamente.
    //
    // No tiene relación con las opciones del menú del ejercicio.
    //
    // =========================================================

    public static boolean esOPTIONS(
            HttpExchange intercambio)
            throws IOException {


        // Verificar si la petición es OPTIONS.

        if (
                intercambio
                        .getRequestMethod()
                        .equalsIgnoreCase(
                                "OPTIONS"
                        )
        ) {


            // Código 204:
            //
            // Petición procesada correctamente,
            // pero sin contenido.

            intercambio.sendResponseHeaders(

                    204,

                    -1
            );


            // Cerrar intercambio.

            intercambio.close();



            // Indicar que sí era OPTIONS.

            return true;

        }



        // No era una petición OPTIONS.

        return false;


    } // fin esOPTIONS



} // fin clase Servidor